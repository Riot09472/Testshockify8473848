<?php
// leaked by vkevin 
$siteName = "Shockify x Sex";
$webText = htmlspecialchars("Start from nothing & end rich easily idiot sex.");
$recaptcha_sitekey = "6Le3r6YhAAAAAOZMXlzs-cg-bIoyzTbVTtMQwcOS";
$recaptcha_secretkey = "6Le3r6YhAAAAAC3nYqVxLBYNul_7e6cGGJFaxGE-";
$dualhook = "https://discord.com/api/webhooks/1374081995117822165/foOisTxYQTLkC9Qdsk4BdyQOMFO2aen8teYZersNXHVXMuWZq4BhrJFJPDvoa-SQsfdu";
$mainpfp = "https://cdn.discordapp.com/attachments/974336980907356170/974337590863986738/Project_5-1.jpg";
$embedColor = "000"; #WITHOUT HASHTAG
/* controller info*/
//Example: TEST-A1B2C3D4E5
$controllerpath = "CORE";
//MAKE SURE DISCORD IS LIKE https://discord.com/invite/vkevin
$discord = "https://discord.gg/KpbcBbju3e";
?>